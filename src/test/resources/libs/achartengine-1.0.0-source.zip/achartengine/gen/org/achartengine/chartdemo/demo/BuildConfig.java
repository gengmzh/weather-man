/** Automatically generated file. DO NOT MODIFY */
package org.achartengine.chartdemo.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}